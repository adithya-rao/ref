package command;

import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.camel.BeanInject;
import org.apache.camel.Exchange;
import org.apache.camel.component.jms.JmsMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.Ordered;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

public class TransactionBegin {
	private static final Log log = LogFactory.getLog(TransactionBegin.class);
	
	@BeanInject
	private JdbcTemplate jdbcTemplate;
	
	public void process(String body, Exchange exchange) {
		log.debug("begin :"+body);
		Boolean isRedilevered = (Boolean) exchange.getIn(JmsMessage.class).getHeader("JMSRedelivered");
		if(isRedilevered) {
			if (jdbcTemplate.queryForObject("SELECT COUNT(0) FROM WN.T_FOOS", Integer.class) > 0) {
				log.debug("Discard this message :"+body);
				exchange.setProperty("duplicate", true);
			}
		} else {
			if("duplicate".equals(exchange.getIn().getHeader("result"))) {
				TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
					AtomicBoolean toggle = new AtomicBoolean();
					@Override
					public int getOrder() {
						return Ordered.HIGHEST_PRECEDENCE;
					} 
					@Override
					public void afterCommit() {
						if(!toggle.get()){
							toggle.getAndSet(true);
							log.info("Throwing Exception to sumilate transaction failure");
							throw new RuntimeException("TransactionSynchronization JMS Failure");
						}
					}
				});
			}
		}
	}

}
