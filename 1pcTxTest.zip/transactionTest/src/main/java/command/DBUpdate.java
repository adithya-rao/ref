package command;

import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.camel.BeanInject;
import org.apache.camel.Exchange;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

public class DBUpdate {
	
	private static final Log log = LogFactory.getLog(DBUpdate.class);
	
	private AtomicInteger count = new AtomicInteger(0);
	
	@BeanInject
	private JdbcTemplate jdbcTemplate;
	
	public void process(String msg, Exchange exchange) throws Exception {
		System.out.println("Received message: [" + msg + "]");

		log.debug("Received message: [" + msg + "]");

		Date date = new Date();
		transactionalUpdate(msg, date, exchange);

		log.debug(String
				.format("Inserted foo with name=%s, date=%s", msg, date));
		//throwException(exchange);
		
	}

	private void throwException(Exchange exchange) {
		if(!exchange.isExternalRedelivered() && "rollback".equals(exchange.getIn().getHeader("result"))) {
			throw new RuntimeException("Trigger Rollback");
		}
	}
	
	@Transactional
	private void transactionalUpdate(String msg, Date date, Exchange exchange) {
		jdbcTemplate.update(
				"INSERT INTO WN.T_FOOS (ID, name, foo_date) values (?, ?,?)", count.getAndIncrement(), msg, date);
		throwException(exchange);
	}
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void resetItemCount() {
		count.set(0);
	}

	public int getItemCount() {
		return count.get();
	}

}
