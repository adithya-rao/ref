package command;

import org.apache.camel.Exchange;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class TransactionEnd {
	private static final Log log = LogFactory.getLog(TransactionEnd.class);
	
	//private final static ThreadLocal<Boolean> toggle = new ThreadLocal<>();
	
	public void process(String body, Exchange exchange) {
		log.debug("end :"+body);		
	}

}
