package command;

import org.apache.camel.Exchange;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ExceptionPropagatorProcessor {
	private static final Log log = LogFactory.getLog(ExceptionPropagatorProcessor.class);
	
	public void process(Exchange exchange) {
		
		exchange.setProperty("HandleException", "RollBack");
		log.debug("in ExceptionPropagatorProcessor");
	}

}
