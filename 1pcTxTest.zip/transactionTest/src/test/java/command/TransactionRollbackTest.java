package command;

import java.util.concurrent.TimeUnit;

import org.apache.camel.BeanInject;
import org.apache.camel.builder.NotifyBuilder;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.jdbc.JdbcTestUtils;

public class TransactionRollbackTest extends TestDBHelper {
	
	@BeanInject 
	private JdbcTemplate jdbcTemplate;
	
	@Before
	public void resetAndSend() throws Exception {
		//clean DB
		jdbcTemplate.update("delete from WN.T_FOOS");
		
		//drain messages
		consumer.receiveBodyNoWait("activemq:incomingOrders");
		//doTestSetup();
		
	}
	
	@Test
	public void testCamelRouteRollback() throws Exception {
		NotifyBuilder notify = new NotifyBuilder(context).whenExactlyFailed(1).and().whenCompleted(1).create();
		
		//send test message
		template.sendBodyAndHeader	("activemq:incomingOrders", "test", "result", "rollback");
		
		long t0 = System.currentTimeMillis();
		while (!notify.matches(10, TimeUnit.SECONDS)) {
		    System.out.println("Notify - Sleeping =====>>> ");
		}

		System.out.println("{} Notify completed, reply took: " +(System.currentTimeMillis() - t0));
		
		//check recored update
		assertEquals(1, JdbcTestUtils.countRowsInTable(jdbcTemplate, "WN.T_FOOS"));
	}

	@Override
	protected ClassPathXmlApplicationContext createApplicationContext() {
		return new ClassPathXmlApplicationContext("camelContext.xml");		
	}

}
