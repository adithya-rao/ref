package command;

import javax.sql.DataSource;

import org.apache.camel.BeanInject;
import org.apache.camel.test.spring.CamelSpringTestSupport;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.test.jdbc.JdbcTestUtils;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

public abstract class TestDBHelper extends CamelSpringTestSupport{
	@BeanInject 
	private DataSource dataSource;
	
	@SuppressWarnings("unchecked")
	protected void cleanDB() {
		TransactionTemplate transactionTemplate = new TransactionTemplate(new DataSourceTransactionManager(dataSource));
		transactionTemplate.execute(new TransactionCallback() {

			@Override
			public Object doInTransaction(TransactionStatus status) {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				jdbcTemplate.update("delete from WN.T_FOOS");
				return null;
			}
			
		});		
	}
	
	@SuppressWarnings("unchecked")
	protected Object countRowsInTable() {
		TransactionTemplate transactionTemplate = new TransactionTemplate(new DataSourceTransactionManager(dataSource));
		return transactionTemplate.execute(new TransactionCallback() {

			@Override
			public Object doInTransaction(TransactionStatus status) {
				JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
				return JdbcTestUtils.countRowsInTable(jdbcTemplate, "WN.T_FOOS");
			}
			
		});		
	}

}
