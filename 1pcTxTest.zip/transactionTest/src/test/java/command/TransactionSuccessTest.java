package command;

import java.util.concurrent.TimeUnit;

import org.apache.camel.builder.NotifyBuilder;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TransactionSuccessTest extends TestDBHelper {
	
	/*@EndpointInject(uri = "activemq:incomingOrders")
    private ProducerTemplate in;
	
	@EndpointInject(uri = "activemq:incomingOrders")
	private ConsumerTemplate out;*/
	
	/*@BeanInject 
	private JdbcTemplate jdbcTemplate;*/
	
	@Before
	public void resetAndSend() throws Exception {
		//clean DB
		cleanDB();
		
		//drain messages
		consumer.receiveBodyNoWait("activemq:incomingOrders");
		
		//doTestSetup();
	}
	
	@Test
	public void testCamelRouteSuccess() throws Exception {
		NotifyBuilder notify = new NotifyBuilder(context).whenCompleted(1).create();
		
		//send test message
		template.sendBodyAndHeader	("activemq:incomingOrders", "test", "result", "success");
		
		long t0 = System.currentTimeMillis();
		while (!notify.matches(10, TimeUnit.SECONDS)) {
		    System.out.println("Notify - Sleeping =====>>> ");
		}

		System.out.println("{} Notify completed, reply took: " +(System.currentTimeMillis() - t0));
		
		//check recored update
		assertEquals(1, countRowsInTable());
		
		//check for any rolledback message
		assertNull(consumer.receiveBodyNoWait("activemq:incomingOrders"));
	}

	@Override
	protected AbstractApplicationContext createApplicationContext() {
		return new ClassPathXmlApplicationContext("camelContext.xml");
	}

}
