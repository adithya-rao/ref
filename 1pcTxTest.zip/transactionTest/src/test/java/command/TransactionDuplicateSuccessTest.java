package command;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.camel.BeanInject;
import org.apache.camel.builder.NotifyBuilder;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

public class TransactionDuplicateSuccessTest extends TestDBHelper {
	
	@BeanInject 
	private JdbcTemplate jdbcTemplate;
	
	@Before
	public void resetAndSend() throws Exception {
		//clean DB
		cleanDB();
		
		//drain messages
		consumer.receiveBodyNoWait("activemq:incomingOrders");
		
		//doTestSetup();
	}
	
	@Test
	public void testCamelRouteDuplicateSuccess() throws Exception {
		//NotifyBuilder notify = new NotifyBuilder(context).whenExactlyFailed(1).and().filter(exchangeProperty("duplicate").isEqualTo(true)).whenDone(1).create();
		NotifyBuilder notify = new NotifyBuilder(context).filter(exchangeProperty("duplicate").isEqualTo(true)).whenCompleted(1).create();
		
		//send test message
		template.sendBodyAndHeader	("activemq:incomingOrders", "test", "result", "duplicate");
		
		long t0 = System.currentTimeMillis();
		while (!notify.matches(10, TimeUnit.SECONDS)) {
		    System.out.println("Notify - Sleeping =====>>> ");
		}

		System.out.println("{} Notify completed, reply took: " +(System.currentTimeMillis() - t0));
		
		//check recored update
		assertEquals(1, countRowsInTable());
		
		//check for any rolledback message
		assertNull(consumer.receiveBodyNoWait("activemq:incomingOrders"));
	}

	@Override
	protected ClassPathXmlApplicationContext createApplicationContext() {
		return new ClassPathXmlApplicationContext("camelContext.xml");		
	}

}
